<!-- jQuery 2.0.2 -->
<script src="{{URL::to('admin_resource/js/jquery.min.js')}}"></script>
<!-- jQuery UI 1.10.3 -->
<!--<script src="{{URL::to('../admin_resource/js/jquery-ui-1.10.3.min.js')}}" type="text/javascript"></script>-->
<!-- Bootstrap -->
<script src="{{URL::to('admin_resource/js/bootstrap.min.js')}}" type="text/javascript"></script>
<!-- Morris.js charts -->
<script src="{{URL::to('admin_resource///cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js')}}"></script>
<script src="{{URL::to('admin_resource/js/plugins/morris/morris.min.js')}}" type="text/javascript"></script>
<!-- Sparkline -->
<script src="{{URL::to('admin_resource/js/plugins/sparkline/jquery.sparkline.min.js')}}" type="text/javascript"></script>
<!-- jvectormap -->
<script src="{{URL::to('admin_resource/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')}}" type="text/javascript"></script>
<script src="{{URL::to('admin_resource/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')}}" type="text/javascript"></script>
<!-- fullCalendar -->
<script src="{{URL::to('admin_resource/js/plugins/fullcalendar/fullcalendar.min.js')}}" type="text/javascript"></script>
<!-- jQuery Knob Chart -->
<script src="{{URL::to('admin_resource/js/plugins/jqueryKnob/jquery.knob.js')}}" type="text/javascript"></script>
<!-- daterangepicker -->
<script src="{{URL::to('admin_resource/js/plugins/daterangepicker/daterangepicker.js')}}" type="text/javascript"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="{{URL::to('admin_resource/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')}}" type="text/javascript"></script>
<!-- iCheck -->
<script src="{{URL::to('admin_resource/js/plugins/iCheck/icheck.min.js')}}" type="text/javascript"></script>
<!-- AdminLTE App -->
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="{{URL::to('admin_resource/js/AdminLTE/dashboard.js')}}" type="text/javascript"></script>
<?php
Route::get('ajax_search_subcategory',['as'=>'ajax_search_subcategory', 'uses'=>'ProductController@ajax_search_subcategory']);
?>
<script>
$("#category_id").change(function () {  
     
        $.ajax({
            url: 'ajax_search_subcategory',
            type: 'GET',
            data: {id: this.value},
            success: function (response)
            {
                $('#subcategory_id').html(response);
            }
        });
});
</script>